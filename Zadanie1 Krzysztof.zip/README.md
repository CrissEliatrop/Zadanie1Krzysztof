# How to run

```
In solution Explorer choose "Conected Services" after that look for two position SQL Server Express LocalDB(local)
Click Configure in Conection string value choose path to file from folder database.

```

# Last modified
2021/04/02
