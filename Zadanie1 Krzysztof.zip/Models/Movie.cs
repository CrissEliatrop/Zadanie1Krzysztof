﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AdvancedProgramming_Lesson1.Models
{
    public class Movie
    {
        [Display(Name = "Identyfikator")]
        public int Id { get; set; }

        [StringLength(60, MinimumLength = 3)]
        [Required]
        [Display(Name = "Tytuł")]
        public string Title { get; set; }

        [DataType(DataType.Date)]
        [Display(Name = "Data Wypuszczenia")]
        public DateTime ReleaseDate { get; set; }
        [Display(Name = "Rodzaj")]
        public string Genre { get; set; }
        [Display(Name = "Cena")]

        [Range(1, 1000)]
        [DataType(DataType.Currency)]
        [Column(TypeName = "decimal(18, 2)")]
        public decimal Price { get; set; }
    }
}
