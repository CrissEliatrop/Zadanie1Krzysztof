# How to run

To run compile and the in Tools -> Nuget Package Manager Console issue the following:

```
Add-Migration InitialCreate
Update-Database
```


# Last modified
2021/03/06
